# 应用程序分层，保持Express在其边界内

<br/><br/>
 
 ### 将组件代码分成web, services, DAL层
![alt text](../../assets/images/structurebycomponents.PNG "Separate component code into layers")

 <br/><br/> 

### 1分钟说明：混合层的缺点
![alt text](../../assets/images/keepexpressinweb.gif "The downside of mixing layers")
