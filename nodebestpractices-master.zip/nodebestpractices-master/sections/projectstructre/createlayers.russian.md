# Выделяйте ваши компоненты в отдельный слой, держите Express в его границах

<br/><br/>

### Разделить код компонента на слои: веб, сервисы и DAL

![alt text](../../assets/images/structurebycomponents.PNG "Separate component code into layers")

 <br/><br/>

### 1 минутное объяснение: обратная сторона смешения слоев

![alt text](../../assets/images/keepexpressinweb.gif "The downside of mixing layers")
