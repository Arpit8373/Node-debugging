# Nakładaj warstwę na aplikację i trzymaj Express w jej granicach

<br/><br/>

 ### Rozdziel kod komponentu na warstwy: sieć, usługi i DAL

![alt text](../../assets/images/structurebycomponents.PNG "Separate component code into layers")

 <br/><br/>

### 1 minuta wyjaśniania: Minusem mieszanie warstw

![alt text](../../assets/images/keepexpressinweb.gif "The downside of mixing layers")
