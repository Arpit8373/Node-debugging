# Coloque seus Componentes em Camadas, mantenha o Express dentro de seus limites

<br/><br/>

 ### Separe o código do componente em camadas: web, serviços e DAL

![alt text](../../assets/images/structurebycomponents.PNG "Separe o código do componente em camadas")

 <br/><br/>

### Explicação em 1 minuto: A desvantagem de misturar camadas

![alt text](../../assets/images/keepexpressinweb.gif "A desvantagem de misturar camadas")
